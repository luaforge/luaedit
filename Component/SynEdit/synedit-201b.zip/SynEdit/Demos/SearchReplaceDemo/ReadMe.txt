SearchReplaceDemo.dpr
---------------------

- Needs Delphi 4 or higher.
- Demonstrates how to implement search and replace functionality with SynEdit.

