//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("B3_RAEditorTest.res");
USEFORMNS("fRAEditorTest.pas", Fraeditortest, Editor);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    try
    {
        Application->Initialize();
        Application->CreateForm(__classid(TEditor), &Editor);
        Application->Run();
    }
    catch (Exception &exception)
    {
        Application->ShowException(&exception);
    }
    return 0;
}
//---------------------------------------------------------------------------
